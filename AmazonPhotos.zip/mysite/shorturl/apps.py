from django.apps import AppConfig


class ShorturlConfig(AppConfig):
    name = 'shorturl'
