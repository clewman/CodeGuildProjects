from django.apps import AppConfig


class MagicballConfig(AppConfig):
    name = 'magicball'


