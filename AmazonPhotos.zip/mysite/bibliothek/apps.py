from django.apps import AppConfig


class BibliothekConfig(AppConfig):
    name = 'bibliothek'
